export enum Company { 
    AnyWhereBikeShop = "Anywhere Bike Shop",
    SelectSpotsBikeShop = "Select Spots Bike Shop",
}