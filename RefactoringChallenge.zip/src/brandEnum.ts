export enum Brand {
  Giant = "Giant",
  Specialized = "Specialized",
  Cannondale = "Cannondale"
}